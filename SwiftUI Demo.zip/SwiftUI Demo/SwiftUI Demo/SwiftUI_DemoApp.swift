//
//  SwiftUI_DemoApp.swift
//  SwiftUI Demo
//
//  Created by Alkesh Fudani on 14/3/21.
//

import SwiftUI

@main
struct SwiftUI_DemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
