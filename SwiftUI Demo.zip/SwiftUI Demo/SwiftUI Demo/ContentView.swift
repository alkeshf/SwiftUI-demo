//
//  ContentView.swift
//  SwiftUI Demo
//
//  Created by Alkesh Fudani on 14/3/21.
//

import SwiftUI

struct User: Identifiable {
    var id: Int
    
    let name, role: String
}

struct ContentView: View {
    
    let users: [User] = [
        .init(id: 0, name: "Elise", role: "IL"),
        .init(id: 1, name: "Parinita", role: "QA"),
        .init(id: 2, name: "Alkesh", role: "Dev"),
        .init(id: 3, name: "Anushelin", role: "PO"),
        .init(id: 4, name: "Abbey", role: "FO"),
        .init(id: 5, name: "Sophie", role: "QA"),
        .init(id: 6, name: "Craig", role: "TL"),
        .init(id: 7, name: "Kartik", role: "Dev"),
        .init(id: 8, name: "Aditya", role: "Dev"),
    ]
    
    var body: some View {
        
        NavigationView {
//            List (users) {
//                Text($0.name).font(.headline)
//            }.navigationBarTitle(Text("Swift UI List"))
            List {
                Text("My List").font(.largeTitle)
                ForEach(users) { user in
                    HStack {
                        Image("test")
                            .resizable()
                            .clipShape(Circle())
                            .overlay(Circle().stroke(Color.blue, lineWidth: 1))
                            .frame(width: 70, height: 70)
                        VStack (alignment: .leading)
                        {
                            Text(user.name).font(.headline)
                            Text(user.role).font(.subheadline)
                        }
                    }

                }
            }.navigationBarTitle(Text("Swift UI List"))
        }
        
    }
}

//#if DEBUG
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
//#endif
